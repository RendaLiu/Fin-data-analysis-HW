import pandas as pd
import numpy as np
from typing import Tuple, List

def handle_MBRevenue(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str], List[str]]:
    """
    处理MBRevenue列的缺失值，基于季度数据和公司历史数据
    
    参数:
    df: 包含"code", "year", "quarter", "MBRevenue"列的DataFrame
    
    返回:
    Tuple[pd.DataFrame, List[str], List[str]]: 
        - 处理后的DataFrame
        - 规则4报告的公司代码+年份列表
        - 规则5报告的公司代码+年份列表
    """
    # 确保数据按公司和时间排序
    df = df.sort_values(['code', 'year', 'quarter']).copy()
    df['MBRevenue_original'] = df['MBRevenue'].copy()  # 保存原始值用于对比
    
    # 初始化报告列表
    rule4_reports = []  # 规则4的报告
    rule5_reports = []  # 规则5的报告
    
    # 获取所有公司代码
    companies = df['code'].unique()
    
    # 为每个公司处理数据
    for company in companies:
        company_mask = df['code'] == company
        company_df = df[company_mask].copy()
        
        # 获取公司的所有年份
        years = company_df['year'].unique()
        
        # 处理每个年份的数据
        for year in years:
            year_mask = company_df['year'] == year
            year_df = company_df[year_mask].copy()
            
            # 获取四个季度的数据
            q_data = {}
            q_indices = {}  # 保存每个季度在DataFrame中的索引
            for q in [1, 2, 3, 4]:
                q_mask = year_df['quarter'] == q
                if q_mask.any():
                    idx = year_df[q_mask].index[0]
                    q_value = year_df.loc[idx, 'MBRevenue']
                    q_data[q] = q_value
                    q_indices[q] = idx
                else:
                    q_data[q] = np.nan
                    q_indices[q] = None
            
            # 情况5: 如果完全没有数据
            if all(pd.isna(q_data[q]) for q in [1, 2, 3, 4]):
                rule5_reports.append(f"{company}_{year}")
                continue
            
            # 情况4: 如果四季度数据都没有
            if pd.isna(q_data[4]):
                # 寻找最近一次有数据的数据值
                historical_data = df[
                    (df['code'] == company) & 
                    (df['quarter'] == 4) & 
                    (~df['MBRevenue'].isna())
                ]
                
                if not historical_data.empty:
                    # 找到最近年份的四季度数据
                    nearest_year = historical_data['year'].max() if historical_data['year'].max() < year else historical_data['year'].min()
                    nearest_value = historical_data[historical_data['year'] == nearest_year]['MBRevenue'].values[0]
                    
                    # 用最近的数据填充四季度
                    q_data[4] = nearest_value
                    
                    # 报告
                    rule4_reports.append(f"{company}_{year}")
                    
                    # 如果二季度有数据，按规则1处理
                    if not pd.isna(q_data[2]):
                        # 规则1: 填充所有季度
                        q_data[2] = q_data[4] / 2  # 二季度 = 四季度/2
                        q_data[1] = q_data[2] / 2  # 一季度 = 二季度/2
                        q_data[3] = q_data[4] / 4  # 三季度 = 四季度/4 (因为(四季度-二季度)/2 = (q4 - q4/2)/2 = q4/4)
                        # 修正: 实际上三季度应该是 (q4 - q2)/2 = (q4 - q4/2)/2 = q4/4
                        q_data[4] = q_data[3]
                    else:
                        # 二季度没有数据，按规则3处理
                        # 规则3: 全年四个季度平均分配
                        avg_value = q_data[4] / 4
                        for q in [1, 2, 3, 4]:
                            q_data[q] = avg_value
                else:
                    # 完全没有四季度历史数据，报告并跳过
                    rule4_reports.append(f"{company}_{year}")
                    continue
            
            # 情况2: 如果2季度没有数据但是4季度有数据
            elif pd.isna(q_data[2]) and not pd.isna(q_data[4]):
                # 寻找其他年份的二、四季度比例
                ratio_data = df[
                    (df['code'] == company) & 
                    (df['quarter'].isin([2, 4])) & 
                    (~df['MBRevenue'].isna())
                ]
                
                # 提取二、四季度数据对
                ratios = []
                for y in df[df['code'] == company]['year'].unique():
                    if y == year:
                        continue
                    
                    year_2q = df[(df['code'] == company) & (df['year'] == y) & (df['quarter'] == 2)]['MBRevenue'].values
                    year_4q = df[(df['code'] == company) & (df['year'] == y) & (df['quarter'] == 4)]['MBRevenue'].values
                    
                    if len(year_2q) > 0 and len(year_4q) > 0 and not pd.isna(year_2q[0]) and not pd.isna(year_4q[0]):
                        ratio = year_2q[0] / year_4q[0]
                        ratios.append((abs(y - year), ratio))
                
                if ratios:
                    # 使用最近年份的比例
                    ratios.sort(key=lambda x: x[0])  # 按年份距离排序
                    nearest_ratio = ratios[0][1]
                    
                    # 计算二季度值
                    q_data[2] = q_data[4] * nearest_ratio
                    
                    # 然后按规则1填充所有季度
                    q_data[1] = q_data[2] / 2
                    q_data[2] = q_data[2] / 2
                    q_data[3] = (q_data[4] - q_data[2]) / 2
                    q_data[4] = q_data[3]
                else:
                    # 情况3: 没有找到比例，全年四个季度平均分配
                    avg_value = q_data[4] / 4
                    for q in [1, 2, 3, 4]:
                        q_data[q] = avg_value
            
            # 情况1: 如果2、4季度有数据，填充所有季度
            elif not pd.isna(q_data[2]) and not pd.isna(q_data[4]):
                # 规则1: 填充所有季度
                if pd.isna(q_data[1]):
                    q_data[1] = q_data[2] / 2
                    q_data[2] = q_data[2] / 2
                if pd.isna(q_data[3]):
                    q_data[3] = (q_data[4] - q_data[2]) / 2
                    q_data[4] = q_data[3]
            
            # 更新DataFrame中的值
            for q, value in q_data.items():
                mask = (df['code'] == company) & (df['year'] == year) & (df['quarter'] == q)
                if mask.any():
                    df.loc[mask, 'MBRevenue'] = value
                    print(f"Updated {company} {year} Q{q} to {value}")
                else:
                    # 如果该季度不存在，添加新行
                    new_row = {
                        'code': company,
                        'year': year,
                        'quarter': q,
                        'MBRevenue': value,
                        'MBRevenue_original': np.nan
                    }
                    # 添加其他列的值（如果有的话）
                    for col in df.columns:
                        if col not in new_row:
                            # 尝试从同公司同年其他季度获取值
                            same_company_year = df[(df['code'] == company) & (df['year'] == year)]
                            if not same_company_year.empty:
                                new_row[col] = same_company_year[col].iloc[0]
                            else:
                                new_row[col] = np.nan
                    
                    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    # 重新排序
    df = df.sort_values(['code', 'year', 'quarter']).reset_index(drop=True)
    
    return df, rule4_reports, rule5_reports


def analyze_MBRevenue_filling(df: pd.DataFrame) -> pd.DataFrame:
    """
    分析MBRevenue列的填充效果
    """
    print("=" * 60)
    print("MBRevenue列填充效果分析")
    print("=" * 60)
    
    # 原始缺失情况
    total_rows = len(df)
    original_missing = df['MBRevenue'].isna().sum()
    original_missing_rate = original_missing / total_rows * 100
    
    print(f"总行数: {total_rows:,}")
    print(f"原始缺失数量: {original_missing:,} ({original_missing_rate:.2f}%)")
    
    # 按季度分析原始缺失
    print("\n原始数据按季度缺失情况:")
    for q in [1, 2, 3, 4]:
        q_mask = df['quarter'] == q
        q_total = q_mask.sum()
        q_missing = df.loc[q_mask, 'MBRevenue'].isna().sum()
        q_missing_rate = q_missing / q_total * 100 if q_total > 0 else 0
        print(f"  第{q}季度: {q_missing:,}/{q_total:,} ({q_missing_rate:.2f}%) 缺失")
    
    # 执行填充
    print("\n正在执行填充...")
    df_filled, rule4_reports, rule5_reports = handle_MBRevenue(df)
    
    # 填充后缺失情况
    filled_missing = df_filled['MBRevenue'].isna().sum()
    filled_missing_rate = filled_missing / total_rows * 100
    
    print(f"填充后缺失数量: {filled_missing:,} ({filled_missing_rate:.2f}%)")
    print(f"填充了 {original_missing - filled_missing:,} 个缺失值")
    
    # 按季度分析填充后情况
    print("\n填充后按季度情况:")
    for q in [1, 2, 3, 4]:
        q_mask = df_filled['quarter'] == q
        q_total = q_mask.sum()
        q_missing = df_filled.loc[q_mask, 'MBRevenue'].isna().sum()
        q_missing_rate = q_missing / q_total * 100 if q_total > 0 else 0
        print(f"  第{q}季度: {q_missing:,}/{q_total:,} ({q_missing_rate:.2f}%) 缺失")
    
    # 报告结果
    print(f"\n规则4报告（四季度缺失但用历史数据填充）: {len(rule4_reports)} 家公司年份")
    if rule4_reports:
        print("示例:")
        for report in rule4_reports[:5]:
            print(f"  - {report}")
        if len(rule4_reports) > 5:
            print(f"  ... 还有 {len(rule4_reports) - 5} 个")
    
    print(f"\n规则5报告（完全没有数据）: {len(rule5_reports)} 家公司年份")
    if rule5_reports:
        print("这些公司年份可能需要删除:")
        for report in rule5_reports[:10]:
            print(f"  - {report}")
        if len(rule5_reports) > 10:
            print(f"  ... 还有 {len(rule5_reports) - 10} 个")
    
    # 分析填充规则使用情况
    print("\n填充规则使用情况分析:")
    
    # 识别哪些值被修改了（对比原始值）
    modified_mask = df_filled['MBRevenue'] != df_filled['MBRevenue_original']
    filled_mask = df_filled['MBRevenue_original'].isna()
    
    # 分类统计
    rule1_count = 0  # 规则1：有2、4季度，填充1、3季度
    rule2_count = 0  # 规则2：只有4季度，找历史比例
    rule3_count = 0  # 规则3：只有4季度，平均分配
    rule4_count = 0  # 规则4：四季度缺失，用历史数据
    
    # 分析每个被修改的值
    for idx in df_filled[modified_mask].index:
        row = df_filled.loc[idx]
        company = row['code']
        year = row['year']
        quarter = row['quarter']
        
        # 获取该年度的四个季度数据
        year_data = df_filled[(df_filled['code'] == company) & (df_filled['year'] == year)]
        q_values = {}
        for q in [1, 2, 3, 4]:
            q_data = year_data[year_data['quarter'] == q]
            if not q_data.empty:
                q_values[q] = q_data['MBRevenue'].iloc[0]
            else:
                q_values[q] = np.nan
        
        # 判断使用哪个规则
        if quarter == 4 and pd.isna(row['MBRevenue_original']):
            # 四季度被填充
            rule4_count += 1
        elif quarter == 2 and pd.isna(row['MBRevenue_original']):
            # 二季度被填充
            if not pd.isna(q_values.get(4, np.nan)):
                rule2_count += 1
        elif quarter in [1, 3] and pd.isna(row['MBRevenue_original']):
            # 一、三季度被填充
            rule1_count += 1
    
    print(f"  规则1填充次数: {rule1_count}")
    print(f"  规则2填充次数: {rule2_count}")
    print(f"  规则3填充次数: {rule3_count}")
    print(f"  规则4填充次数: {rule4_count}")
    
    # 显示处理前后的对比
    print("\n处理前后对比示例:")
    sample_companies = df_filled['code'].unique()[:3]
    for company in sample_companies:
        company_data = df_filled[df_filled['code'] == company]
        years = company_data['year'].unique()[:2]
        
        for year in years:
            year_data = company_data[company_data['year'] == year]
            print(f"\n公司 {company}, 年份 {year}:")
            for _, row in year_data.iterrows():
                quarter = row['quarter']
                original = row['MBRevenue_original']
                filled = row['MBRevenue']
                if pd.isna(original):
                    print(f"  第{quarter}季度: 缺失 -> {filled:.2f}")
                elif original != filled:
                    print(f"  第{quarter}季度: {original:.2f} -> {filled:.2f}")
                else:
                    print(f"  第{quarter}季度: {original:.2f} (未修改)")
    
    return df_filled

def handle_gpmargin_with_npmargin(df):
    """
    利用净利率（npMargin）补全毛利率（gpMargin）：
    1. 第一步：用有完整gpMargin+npMargin的样本训练线性回归模型；
    2. 第二步：基于npMargin预测缺失的gpMargin；
    3. 第三步：兜底填充（公司均值→全局均值）；
    4. 保留已有gpMargin数据，仅填充缺失值。
    """
    df = df.copy()
    # 确保数值型
    df['gpMargin'] = pd.to_numeric(df['gpMargin'], errors='coerce')
    df['npMargin'] = pd.to_numeric(df['npMargin'], errors='coerce')
    
    # ===================== 第一步：训练线性回归模型（基于有效样本） =====================
    # 筛选同时有gpMargin和npMargin的有效样本（用于训练）
    valid_samples = df[(df['gpMargin'].notnull()) & (df['npMargin'].notnull())].copy()
    if len(valid_samples) > 10:  # 样本数足够才训练模型
        from sklearn.linear_model import LinearRegression
        # 特征：净利率（npMargin），目标：毛利率（gpMargin）
        X = valid_samples[['npMargin']].values
        y = valid_samples['gpMargin'].values
        # 训练模型
        lr_model = LinearRegression()
        lr_model.fit(X, y)
        
        # ===================== 第二步：用模型预测缺失的gpMargin =====================
        # 筛选gpMargin缺失但npMargin存在的样本
        mask_pred = (df['gpMargin'].isnull()) & (df['npMargin'].notnull())
        if mask_pred.sum() > 0:
            # 基于npMargin预测gpMargin
            pred_gp = lr_model.predict(df.loc[mask_pred, ['npMargin']].values)
            # 合理性校验：毛利率不能为负，且通常大于净利率（限制在0~100区间）
            pred_gp = np.clip(pred_gp, a_min=0, a_max=100)
            # 填充预测值
            df.loc[mask_pred, 'gpMargin'] = pred_gp
    
    # ===================== 第三步：兜底填充（极端情况） =====================
    # 仍缺失的（比如npMargin也缺失）：用公司均值填充
    gp_company_mean = df.groupby('code')['gpMargin'].mean().reset_index()
    gp_company_mean.rename(columns={'gpMargin': 'gp_company_mean'}, inplace=True)
    df = df.merge(gp_company_mean, on='code', how='left')
    df['gpMargin'] = df['gpMargin'].fillna(df['gp_company_mean'])
    
    # 最终兜底：全局均值（确保无NaN）
    df['gpMargin'] = df['gpMargin'].fillna(df['gpMargin'].mean())
    
    # 删除临时列
    df = df.drop('gp_company_mean', axis=1)
    return df

def calculate_growth_v3(df, col):
    """优化版增长率计算：无NaN/无穷大"""
    df = df.sort_values(['code', 'year', 'quarter'])
    df[col] = df.groupby('code')[col].fillna(method='ffill').fillna(method='bfill').fillna(0)
    df[f'{col}_growth'] = df.groupby('code')[col].pct_change(1)
    df[f'{col}_growth'] = df[f'{col}_growth'].replace([np.inf, -np.inf], 0).fillna(0)
    return df

# 测试代码
if __name__ == "__main__":
    # 创建测试数据
    np.random.seed(42)
    
    # 创建10个公司，3年的数据
    n_companies = 10
    n_years = 3
    
    test_data = []
    for i in range(n_companies):
        company_code = f'STK{i:04d}'
        for year in range(2020, 2020 + n_years):
            # 为每个季度生成基础值
            base_value = np.random.uniform(100, 1000)
            
            # 模拟不同的缺失模式
            for q in [1, 2, 3, 4]:
                # 创建不同的缺失模式
                if q == 1:
                    # 一季度大部分缺失
                    if np.random.rand() < 0.8:
                        value = np.nan
                    else:
                        value = base_value + np.random.normal(0, 50)
                elif q == 2:
                    # 二季度部分缺失
                    if np.random.rand() < 0.3:
                        value = np.nan
                    else:
                        value = base_value * 0.5 + np.random.normal(0, 50)
                elif q == 3:
                    # 三季度大部分缺失
                    if np.random.rand() < 0.8:
                        value = np.nan
                    else:
                        value = base_value + np.random.normal(0, 50)
                else:  # q == 4
                    # 四季度少量缺失
                    if np.random.rand() < 0.1:
                        value = np.nan
                    else:
                        value = base_value + np.random.normal(0, 50)
                
                test_data.append({
                    'code': company_code,
                    'year': year,
                    'quarter': q,
                    'MBRevenue': value,
                    'other_column': np.random.randn()  # 其他列示例
                })
    
    test_df = pd.DataFrame(test_data)
    
    print("测试数据前20行:")
    print(test_df[['code', 'year', 'quarter', 'MBRevenue']].head(20))
    
    # 运行分析
    result_df = analyze_MBRevenue_filling(test_df)
    
    print("\n处理后的数据示例:")
    print(result_df[['code', 'year', 'quarter', 'MBRevenue_original', 'MBRevenue']].head(20))
    
    # 验证规则应用
    print("\n验证规则应用:")
    # 检查一个具体例子
    test_company = 'STK0000'
    test_year = 2020
    test_rows = result_df[(result_df['code'] == test_company) & (result_df['year'] == test_year)]
    
    if not test_rows.empty:
        print(f"\n公司 {test_company} 在 {test_year} 年的数据:")
        for _, row in test_rows.iterrows():
            quarter = row['quarter']
            original = row['MBRevenue_original']
            filled = row['MBRevenue']
            print(f"  第{quarter}季度: 原始={original:.2f}, 填充后={filled:.2f}")
        
        # 验证规则
        q_values = {}
        for _, row in test_rows.iterrows():
            q_values[row['quarter']] = row['MBRevenue']
        
        print(f"\n验证计算:")
        if 2 in q_values and 4 in q_values:
            print(f"  一季度应该 = 二季度/2: {q_values.get(1, 'N/A')} ≈ {q_values[2]/2:.2f}")
            print(f"  三季度应该 = (四季度-二季度)/2: {q_values.get(3, 'N/A')} ≈ {(q_values[4]-q_values[2])/2:.2f}")
    # 假设你的DataFrame叫做fin_df
    # 确保fin_df包含必要的列
    required_cols = ['code', 'year', 'quarter', 'MBRevenue']
    
    # 创建示例数据
    np.random.seed(42)
    n_companies = 5
    n_years = 3
    
    sample_data = []
    for i in range(n_companies):
        company_code = f'stock{i:04d}'
        for year in range(2020, 2020 + n_years):
            for q in [1, 2, 3, 4]:
                # 模拟缺失模式：1、3季度大部分缺失，2、4季度部分缺失
                if q in [1, 3]:
                    # 1、3季度有90%概率缺失
                    if np.random.rand() < 0.9:
                        value = np.nan
                    else:
                        value = np.random.randn() * 100 + 500
                elif q == 2:
                    # 2季度有20%概率缺失
                    if np.random.rand() < 0.2:
                        value = np.nan
                    else:
                        value = np.random.randn() * 100 + 500
                else:  # q == 4
                    # 4季度有10%概率缺失
                    if np.random.rand() < 0.1:
                        value = np.nan
                    else:
                        value = np.random.randn() * 100 + 500
                
                sample_data.append({
                    'code': company_code,
                    'year': year,
                    'quarter': q,
                    'MBRevenue': value,
                    'other_col': np.random.rand()  # 其他列示例
                })
    
    fin_df_sample = pd.DataFrame(sample_data)
    
    print("处理前的数据示例:")
    print(fin_df_sample.head(20))
    
    # 执行填充和分析
    df_filled = analyze_MBRevenue_filling(fin_df_sample)
    
    print("\n处理后的数据示例:")
    print(df_filled[['code', 'year', 'quarter', 'MBRevenue']].head(20))